/* ============================================================================
 * D Y N I B E X - STL formula verification on tube
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Jul 22, 2025
 * Modified    : Jul 22, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */
#ifndef Simu_tools_H
#define Simu_tools_H

#include "ibex.h"
#include "CSTL.h"
#include <vector>
#include <string>
#include <utility>
#include <iostream>
#include <fstream>
#include <sstream>
#include <iomanip>

using namespace std;
using namespace ibex;

typedef pair<pair<int, vector<int>>, pair<double, double>> TimeInterval;

struct node {
    std::vector<int> path_index;
    std::vector<std::pair<ibex::IntervalVector, ibex::Interval>> Jn_vector;
    std::vector<Affine2Vector> final_box;
    std::vector<std::vector<Affine2Vector>> paved_boxes;

    node(const int& seq_index,
         const Affine2Vector& yinit_aff,
         const std::vector<int>& branche_list,
         const std::vector<Affine2Vector>& Inputs);
};

// ---------------- Prototypes ----------------

std::pair<Affine2Vector,  std::vector<std::pair<IntervalVector, Interval>>>simulation_P(const std::vector<Affine2Vector>& Inputs, const Affine2Vector& Initial_Value, const int& num);
// Conversion Box -> Affine2Vector
std::vector<Affine2Vector> Box_to_Affine_list(const Affine2Vector& yinit_aff);

// Traitement de toutes les simulations
void process_all_simulations(
    const std::vector<std::pair<ibex::simulation&, double>>& simurecord,
    const std::vector<ibex::IntervalVector>& predicate_list,
    const std::vector<int>& selected_indices,
    const std::string& base_predicate_name,
    const std::string& base_jnbox_name);

// Extraction des jn_box depuis une simulation
std::vector<std::pair<ibex::IntervalVector, ibex::Interval>> extract_jn_box(ibex::simulation& sim);

// Création des inputs NN à partir de l’état
std::vector<Affine2Vector> NN_inputs_from_state(const Affine2Vector& input, const std::vector<int>& index);

// Enlever les intervalles de temps nulles
std::vector<std::vector<std::pair<ibex::IntervalVector, ibex::Interval>>> remove_null_intervals(
    const std::vector<std::vector<std::pair<ibex::IntervalVector, ibex::Interval>>>& Real_time_branching);

// Reconstruire le temps réel des branches
std::vector<std::vector<std::pair<ibex::IntervalVector, ibex::Interval>>> reconstruct_real_time(
    const std::vector<std::vector<std::pair<ibex::IntervalVector, ibex::Interval>>>& Final_branching);

// Enregistrer la structure de branching finale
void recordFinalBranching(const std::vector<std::vector<std::pair<ibex::IntervalVector, ibex::Interval>>>& Final_branching);

// Reconstruction et enregistrement du branching à partir de l’arbre
void Recording_simulation(const std::vector<std::vector<node>>& final_tree);

// Reconstruction sans enregistrement
std::vector<std::vector<std::pair<ibex::IntervalVector, ibex::Interval>>> Getting_jn_branch_from_tree(
    const std::vector<std::vector<node>>& final_tree);

// Calcul du résultat global sur toutes les branches
int Compute_result_all_branches(const std::vector<int>& pre_values);


#endif // Simu_tools_H

