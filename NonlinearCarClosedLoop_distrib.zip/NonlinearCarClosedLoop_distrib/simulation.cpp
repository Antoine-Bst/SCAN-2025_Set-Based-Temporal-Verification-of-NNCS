/* ============================================================================
 * D Y N I B E X - STL formula verification on tube
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Jul 22, 2025
 * Modified    : Jul 22, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */

#include "ibex.h"
#include <fstream>
#include <iostream>
#include "CSTL.h"
#include <iomanip>  // for std::setprecision
#include <vector>
#include <random>
#include <limits>
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <unordered_map>
#include "DnnAff.h"
#include "Simu_tools.h"

using namespace ibex;
using namespace std;


//using Point = std::vector<double>;


int Verify_STL(const std::vector<std::vector<std::pair<IntervalVector, Interval>>>& jn_branches){
    //mettre formule stl sur chaque branche

  vector<IntervalVector> p_list; ///predicate list
   const int n = 6;
  IntervalVector predicate1(n);
    predicate1[0] = Interval(1.75, 2);
    predicate1[1] = Interval(1.75, 2);
    predicate1[2] = Interval(-1000,1000);
    predicate1[3] = Interval(-1000,1000);
    predicate1[4] = Interval(-1000,1000);
    predicate1[5] = Interval(-1000,1000);

   IntervalVector predicate2(n);
    predicate2[0] = Interval(0,0.5);
    predicate2[1] = Interval(0.75,1.25);
    predicate2[2] = Interval(-1000,1000);
    predicate2[3] = Interval(-1000,1000);
    predicate2[4] = Interval(-1000,1000);
    predicate2[5] = Interval(-1000,1000);


    IntervalVector predicate3(n);
    predicate3[0] = Interval(0.5, 1.5);
    predicate3[1] = Interval(0.25, 1.5);
    predicate3[2] = Interval(-1000,1000);
    predicate3[3] = Interval(-1000,1000);
    predicate3[4] = Interval(-1000,1000);
    predicate3[5] = Interval(-1000,1000);
    p_list = {predicate1,predicate2, predicate3};


    vector<int> list_result; //resultat pour toute les branches
    for (size_t i = 0; i < jn_branches.size(); i++)
    {
        //verification on every branches
    std::pair<std::vector<vector<TimeInterval>>, std::vector<Interval>> P_Satisfaction_signals = predicate_satisfaction_jn(jn_branches[i], p_list);
    vector<TimeInterval> Phi1;
        Phi1 = and_stl_titv(and_stl_titv(Globally(neg_stl_titv(P_Satisfaction_signals.first[2]), {0, 8}), Globally( or_stl_titv( Finally(P_Satisfaction_signals.first[1], {2,4}), neg_stl_titv(P_Satisfaction_signals.first[0])), {0, 7})), Finally(P_Satisfaction_signals.first[0], {5,7}) );
        //print_TimeIntervals(Phi1);
        int result = satisfies_at_time(0, Phi1);
        list_result.push_back(result);
        if (result == -2) //if one branch is incomplete we continue
        {
            break;
        }
    }

    int final_result = Compute_result_all_branches(list_result);
    std::cout<<"Satisfaction Computed: "<<final_result<<std::endl;
    return final_result;

}

int main(){

std::vector<std::vector<node>> final_tree;

    const int n= 6; ///nombre d'état dans le système différentiel
    Variable y(n);
    IntervalVector yinit(n);
    yinit[0] = Interval(0,0.01);  //x
    yinit[1] = Interval(0,0.01);   //y
    yinit[2] = Interval(0);  //u'
    yinit[3] = Interval(0);  //theta'
    yinit[4] = Interval(0.5);  //v_ref
    yinit[5] = Interval(0);  //theta_ref

  AF_fAFFullI::setAffineNoiseNumber(500);
  Affine2Vector yinit_aff(yinit, true);

    std::vector<node> init_row;
    init_row.push_back(node(0, yinit_aff,{},NN_inputs_from_state(yinit_aff, {0,1,5})));
    final_tree.push_back(init_row);
std::cout<<"---------------simulation initiale---------------"<<std::endl;

    for (size_t i = 1; i < 25; i++)
    {
        std::cout<<"---------------Sequence : "<< i <<"---------------"<<std::endl;
        std::vector<node> temp_row;

        for (size_t j = 0; j < final_tree[i-1].size(); j++)
        {   
            for (size_t k = 0; k < final_tree[i-1][j].paved_boxes.size(); k++)
            {
                std::cout<<"---------------Noeud : "<< temp_row.size() <<"---------------"<<std::endl;
                temp_row.push_back(node(temp_row.size(), 
                final_tree[i-1][j].final_box[0], 
                final_tree[i-1][j].path_index, 
                final_tree[i-1][j].paved_boxes[k]
                ));//We recursively build simulation object as the simulation can branch to maintain accuracy
            }
        }

        final_tree.push_back(temp_row);
        int status = Verify_STL(Getting_jn_branch_from_tree(final_tree));
        if (status != -2) //if the simulation is longer enough to satute on the satisfaction we end it. In this case the required formula length is 11s and 22 steps but we can conclude at 18 steps (9s)
        {
           break;
        }
        
    }

//Recording_simulation(final_tree);

return 1;
}
