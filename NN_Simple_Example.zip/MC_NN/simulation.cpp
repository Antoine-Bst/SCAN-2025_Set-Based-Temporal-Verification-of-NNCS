/* ============================================================================
 * D Y N I B E X - MLP Reachability Analysis
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Sept 21, 2025
 * Modified    : Sept 21, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */

#include "ibex.h"
#include <fstream>
#include <iostream>
#include <vector>
#include <cmath>
#include <stdexcept>
#include "DnnAff.h"

using namespace ibex;
using namespace std;

int main(){
std::ofstream sim_result;
sim_result.open("sim_result_aff.txt");
    const int n= 1; ///nombre d'état dans le système différentiel
    
    IntervalVector Y1(n);
    IntervalVector Y2(n);
    IntervalVector Y3(n);
    
    IntervalVector Outplot(2);
    Affine2Vector Outplot_aff(Outplot, true);
    Y1[0] = Interval(1.8,1.85);   //x
    Y2[0] = Interval(1.8,1.85);   //y
    Y3[0] = Interval(5,5);     //time
    
  AF_fAFFullI::setAffineNoiseNumber(2500);
  Affine2Vector Y1_aff(Y1, true);
  Affine2Vector Y2_aff(Y2, true);
  Affine2Vector Y3_aff(Y3, true);
  
  std::vector<Affine2Vector> Inputs = {Y1_aff, Y2_aff, Y3_aff};
  std::vector<Affine2Vector> output = DeepNeuralNetwork_aff(Inputs, "weights.txt", "biases.txt");
   AF_fAFFullI::setAffineNoiseNumber(8);
   output[0].compact();
   output[1].compact();
   
   Outplot_aff[0] = output[0][0];
   Outplot_aff[1] = output[1][0];
   
  std::cout<<"First Dim: " << output[0] <<" | Second Dim: "<< output[1] <<std::endl; //to display the computed affine forms
  
  sim_result<<output[0] <<" ; "<< output[1] <<std::endl;
  
  sim_result.close();
return 1;
}
