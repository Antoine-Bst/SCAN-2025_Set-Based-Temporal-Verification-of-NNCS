#include "ibex.h"
#include <fstream>
#include <iostream>
#include "CSTL_Tools.h"
#include "CSTL.h"
#include <iomanip>  // for std::setprecision

#include <vector>
//#include <limits>
//#include <algorithm>


using namespace ibex;
using namespace std;


double sum_durations_status_2(const std::vector<TimeInterval>& intervals) {
    double total_duration = 0.0;
///on calcul le temps total d'incertitude
    for (const auto& interval : intervals) {
        int status = interval.first.first;
        double start = interval.second.first;
        double end = interval.second.second;

        if (status == 2) {
            total_duration += (end - start);
        }
    }

    return total_duration;
}

vector<double> Bisection_time(const vector<Interval>& Un_origin, const double& min_step_time){
  //on bisecte des intervals avec un pas limite
   std::vector<double> vec;

  for (size_t i = 0; i < Un_origin.size(); i++)
  {
    if (Un_origin[i].ub()-Un_origin[i].lb() > min_step_time)
    {
          vec.push_back(Un_origin[i].mid());
    }
  }
    // Trier le vecteur
    std::sort(vec.begin(), vec.end());
    // Supprimer les doublons adjacents
    vec.erase(std::unique(vec.begin(), vec.end()), vec.end());
    // Afficher le résultat
  return vec;
}

vector<Interval> Uncertainty_origin(vector<TimeInterval> Phi1, const vector<Interval>& P_Satisfaction_signals){
vector<Interval> result;
for (size_t i = 0; i < Phi1.size(); i++)
    {
        if (Phi1[i].first.first == 2)
        {
            Phi1[i].first.second = minusonecleaner(Phi1[i].first.second);
            std::cout << "uncertainty index "<<i<<": ";
            if (Phi1[i].first.second[0]==-2)
            {
              std::cout <<"Incomplete simulation ["<< Phi1[i].second.first <<", "<<Phi1[i].second.second<<"]"<<std::endl;
            }
            
            for (size_t j = 0; j < Phi1[i].first.second.size(); j++)
            {
                if (Phi1[i].first.second[j] >= 0)
                {
                  std::cout << Phi1[i].first.second[j] <<", titv: "<< P_Satisfaction_signals[Phi1[i].first.second[j]] << " | ";
                  result.push_back(P_Satisfaction_signals[Phi1[i].first.second[j]]);
                }
            }
            std::cout<<std::endl;
        }
    }
 return result;
}


void process_and_save_data(ibex::simulation& sim, 
                           const vector<IntervalVector>& predicate_list, 
                           const vector<int>& selected_indices,
                           const string& predicate_file,
                           const string& jn_box_file) {
    // Extract jn_box from sim
    vector<pair<IntervalVector, Interval>> jn_box;
    for (const auto& sol : sim.list_solution_g) {
        if (sol.box_jn && (sol.time_j.lb() >= 0)) { 
            jn_box.push_back({*sol.box_j1, sol.time_j});
        }
    }

    // Open files for writing
    ofstream predFile(predicate_file);
    ofstream jnBoxFile(jn_box_file);

    if (!predFile || !jnBoxFile) {
        cerr << "Error: Unable to open files for writing!" << endl;
        return;
    }

    // Writing selected indices from predicate_list
    for (size_t j = 0; j < predicate_list.size(); j++) {
        for (int n : selected_indices) { // Iterate over selected indices
            if (n < predicate_list[j].size()) { // Ensure index is within bounds
                predFile << predicate_list[j][n] << " ";
            }
        }
        predFile << "\n";
    }
    bool isempty = false;
    // Writing selected indices from jn_box
    for (size_t i = 0; i < jn_box.size(); i++) {
        for (int n : selected_indices) { // Iterate over selected indices
            if (n < jn_box[i].first.size()) { // Ensure index is within bounds
                if (jn_box[i].first[n].is_empty())
                {
                  isempty = true;
                }
                
                if (!isempty)
                {
                  jnBoxFile << jn_box[i].first[n] << " ";
                }
            }
        }
        if (!isempty)
        {
         jnBoxFile << "\n";
        }      
        isempty= false;
    }

    // Close files
    predFile.close();
    jnBoxFile.close();
    std::cout << "Files saved: " << predicate_file << ", " << jn_box_file << endl;
}

int satisfies_at_time(const double& time, const vector<TimeInterval>& phi){
int result;
for (size_t i = 0; i < phi.size(); i++)
{
  if (phi[i].second.second > time)
  {
    result = phi[i].first.first;
    return result;
  }  
}
return 3; ///unknown
}

void process_all_simulations(const std::vector<std::pair<ibex::simulation&, double>>& simurecord,
                             const std::vector<ibex::IntervalVector>& predicate_list,
                             const std::vector<int>& selected_indices,
                             const std::string& base_predicate_name,
                             const std::string& base_jnbox_name) {
    
    size_t i = 0;
    while (i < simurecord.size()) {
        ibex::simulation& sim = simurecord[i].first;
        double suffix = simurecord[i].second;

        // Format the suffix
        std::ostringstream pred_filename, jnbox_filename;
        pred_filename << base_predicate_name << "_" << std::fixed << std::setprecision(3)  << suffix << ".txt";
        jnbox_filename << base_jnbox_name << "_" << std::fixed << std::setprecision(3)  << suffix << ".txt";

        std::cout << "Processing simulation " << i << " -> " << pred_filename.str() << ", " << jnbox_filename.str() << std::endl;

        process_and_save_data(sim, predicate_list, selected_indices, pred_filename.str(), jnbox_filename.str());

        ++i;
    }
}

void record_satisfaction(const std::vector<TimeInterval>& TimeIntervals,
                                             const std::string& base_file_path,
                                             double suffix) {
    std::ostringstream filename;
    filename << base_file_path << "_" << std::fixed << std::setprecision(3) << suffix << ".txt";

print_TimeIntervals_to_file(TimeIntervals, filename.str());


}

