/* ============================================================================
 * D Y N I B E X - STL formula verification on tube
 * ============================================================================
 * Copyright   : ENSTA
 * License     : This program can be distributed under the terms of the GNU LGPL.
 *               See the file COPYING.LESSER.
 *
 * Author(s)   : Antoine Besset, Joris Tillet and Julien Alexandre dit Sandretto
 * Created     : Jul 22, 2025
 * Modified    : Jul 22, 2025
 * Sponsored   : This research benefited from the support of the "STARTS Projects - CIEDS - Institut Polytechnique"
 * ---------------------------------------------------------------------------- */

#ifndef CSTL_Tools_H
#define CSTL_Tools_H

#include "ibex.h"
#include <fstream>
#include <iostream>
#include "CSTL.h"
#include <iomanip>  // for std::setprecision
#include <vector>


using namespace std;
using namespace ibex;

double sum_durations_status_2(const std::vector<TimeInterval>& intervals);
vector<double> Bisection_time(const vector<Interval>& Un_origin, const double& min_step_time);
vector<Interval> Uncertainty_origin(vector<TimeInterval> Phi1, const vector<Interval>& P_Satisfaction_signals);
void process_and_save_data(ibex::simulation& sim, 
                           const vector<IntervalVector>& predicate_list, 
                           const vector<int>& selected_indices,
                           const string& predicate_file,
                           const string& jn_box_file); //on save une seule simulation
void process_all_simulations(const std::vector<std::pair<ibex::simulation&, double>>& simurecord,
                             const std::vector<ibex::IntervalVector>& predicate_list,
                             const std::vector<int>& selected_indices,
                             const std::string& base_predicate_name,
                             const std::string& base_jnbox_name); //on save plusieurs simulations
void record_satisfaction(const std::vector<TimeInterval>& TimeIntervals,
                                             const std::string& base_file_path,
                                             double suffix); //outils d'enregistrement de la satisfaction d'un signal de satisfaction, suffix c'est pour versioner le fichier
int satisfies_at_time(const double& time, const vector<TimeInterval>& phi);                                        

#endif // CSTL_H

