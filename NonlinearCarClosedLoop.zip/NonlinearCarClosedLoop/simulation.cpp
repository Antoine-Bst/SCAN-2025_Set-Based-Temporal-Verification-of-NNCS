#include "ibex.h"
#include <fstream>
#include <iostream>
#include "CSTL.h"
#include <iomanip>  // for std::setprecision
#include "CSTL_Tools.h"
#include <vector>
#include <random>
#include <limits>
#include <algorithm>
#include <cmath>
#include <stdexcept>
#include <unordered_map>
#include "DnnAff.h"

#define Universe_dim 3

using namespace ibex;
using namespace std;


using Point = std::vector<double>;


std::vector<Affine2Vector> Box_to_Affine_list(const Affine2Vector& yinit_aff){
std::vector<Affine2Vector> output;

IntervalVector temporary(1);
Affine2Vector temporary_aff(temporary, true);

for (size_t i = 0; i < 2; i++)
{
    temporary_aff[0] = yinit_aff[i];
   output.push_back(temporary_aff);
}

    temporary_aff[0] = yinit_aff[5]; //pour le temp
   output.push_back(temporary_aff);

return output;
}


std::vector<std::pair<IntervalVector, Interval>> extract_jn_box(ibex::simulation& sim) {
    std::vector<std::pair<IntervalVector, Interval>> jn_box;
    for (const auto& sol : sim.list_solution_g) {
        if (sol.box_jn) { // Ensure it's not NULL
            jn_box.push_back({*sol.box_j1,sol.time_j}); // Dereference pointer
        }
    }

    return jn_box;
}

std::pair<Affine2Vector,  std::vector<std::pair<IntervalVector, Interval>>>simulation_P(const std::vector<Affine2Vector>& Inputs, const Affine2Vector& Initial_Value, const int& num)
{
    const int n= 6; ///nombre d'état dans le système différentiel
    Variable y(n);
    IntervalVector Box(n);
    IntervalVector yinit(n);
    yinit[0] = Interval(0);  //x
    yinit[1] = Interval(0);   //y
    yinit[2] = Interval(0);  //u'
    yinit[3] = Interval(0);  //theta'
    yinit[4] = Interval(2);  //v_ref
    yinit[5] = Interval(1);  //theta_ref

  AF_fAFFullI::setAffineNoiseNumber(500);
  Affine2Vector yinit_aff(yinit, true);

    yinit_aff[0] = Initial_Value[0];
    yinit_aff[1] = Initial_Value[1];
    yinit_aff[2] = Initial_Value[2];
    yinit_aff[3] = Initial_Value[3];
    yinit_aff[4] = Inputs[0][0];
    yinit_aff[5] = Inputs[1][0];

    Interval K_c = Interval(4.95, 5);
    Interval K_v = Interval(2.05, 2.1);
    Interval Const = Interval(0);

      const double tsimu=0.5;

      Function ydot = Function(y,Return(
      ibex::cos(y[3])*y[2], ibex::sin(y[3])*y[2], K_v*(y[4] - y[2]), K_c*(y[5]- y[3]),  Const, Const
      ));
      ivp_ode problem = ivp_ode(ydot,0.0,yinit_aff);    
      simulation simu = simulation(&problem,tsimu,RK4,1e-9);
//virer le p et le D pour l'expe univariable
      simu.run_simulation();

    //IntervalVector temp = simu.get_tight(1);

 vector<IntervalVector> p_list; ///liste des prédicats

  IntervalVector predicate1(n); //v
    predicate1[0] = Interval(0);
    predicate1[1] = Interval(0);

    p_list = {predicate1};
    std::vector<std::pair<IntervalVector, Interval>> tube_record = extract_jn_box(simu);
   // std::cout<< temp[1]<<" : à 1s"<<std::endl;
    process_all_simulations({{simu, num}}, p_list, {0, 1}, "result/predicate", "result/jn_box");

    yinit_aff = simu.get_last_aff();

        IntervalVector tempor(1); //temporary variable
        tempor[0] = Interval(num*tsimu); //on passe le temps dans les états pour le NN
        Affine2Vector tempor_aff(tempor, true);
    yinit_aff[5] = tempor_aff[0];
return make_pair(yinit_aff, tube_record);
}

std::vector<Affine2Vector> NN_inputs_from_state(const Affine2Vector& input, const std::vector<int>& index){

    std::vector<Affine2Vector> out;
        IntervalVector input1(1); //temporary variable
        input1[0] = Interval(0);
        Affine2Vector input1_aff(input1, true);

    for (size_t i = 0; i < index.size(); i++)
    {
        input1_aff[0] = input[index[i]];
        out.push_back(input1_aff);
    }
        return out;
}


struct node {
  std::vector<int> path_index;
  std::vector<std::pair<IntervalVector, Interval>> Jn_vector;
  std::vector<Affine2Vector> final_box;
  std::vector<std::vector<Affine2Vector>> paved_boxes;

      node(const int& seq_index, const Affine2Vector& yinit_aff, const vector<int>& branche_list, const std::vector<Affine2Vector>& Inputs){
        const int n_pavage = 2;
        path_index = branche_list;
        path_index.push_back(seq_index); //on a construit le nouveau chemin d'indice dans l'arbre
        
        std::vector<Affine2Vector> output = DeepNeuralNetwork_aff(Inputs , "weights.txt", "biases.txt");
        Affine2Vector transformed_yinit_aff = yinit_aff;
        transformed_yinit_aff[0]=Inputs[0][0];
        transformed_yinit_aff[1]=Inputs[1][0]; ///là on met à jour pour la dynamique la partition de l'espace

        std::pair<Affine2Vector,  std::vector<std::pair<IntervalVector, Interval>>> simulation = simulation_P(output, transformed_yinit_aff, branche_list.size());

        final_box= {simulation.first};
        Jn_vector = simulation.second;
        if (simulation.first[0].itv().diam()*simulation.first[1].itv().diam()>0.0625)//critère de bisection
        {
            paved_boxes = Affine2Splitter(Box_to_Affine_list(simulation.first), n_pavage);
        }
        else
        {
            paved_boxes = {Box_to_Affine_list(simulation.first)};
        }
        

      }
};
//function pour enlever les intervalles de temps nulles
std::vector<std::vector<std::pair<IntervalVector, Interval>>> remove_null_intervals(
    const std::vector<std::vector<std::pair<IntervalVector, Interval>>>& Real_time_branching) {
    
    std::vector<std::vector<std::pair<IntervalVector, Interval>>> Filtered_branching;

    for (const auto& branch : Real_time_branching) {
        std::vector<std::pair<IntervalVector, Interval>> filtered_branch;
        
        for (const auto& segment : branch) {
            const Interval& time_interval = segment.second;
            
            // Check if interval is null
            if (time_interval.lb() != time_interval.ub()) {
                filtered_branch.push_back(segment); // Keep only valid intervals
            }
        }
        
        // Add non-empty branches to the final list
        if (!filtered_branch.empty()) {
            Filtered_branching.push_back(filtered_branch);
        }
    }

    return Filtered_branching;
}

std::vector<std::vector<std::pair<IntervalVector, Interval>>> reconstruct_real_time(
    const std::vector<std::vector<std::pair<IntervalVector, Interval>>>& Final_branching) {
    
    std::vector<std::vector<std::pair<IntervalVector, Interval>>> Real_time_branching = Final_branching;

    for (auto& branch : Real_time_branching) {
        double cumulative_time = 0.0; // Initialize real time counter for each branch
        for (auto& segment : branch) {
            Interval& time_interval = segment.second;

            // Compute the duration using the framework's methods
            double duration = time_interval.ub() - time_interval.lb();
            if (time_interval.lb()<0)
            {
              duration = 0; //les boxs jn sont initialisé entre -0.01 et 0 ce qui crée un décalage dans toutes la branche
            }
            
            // Update time interval with accumulated real time
            double new_lb = cumulative_time;
            double new_ub = cumulative_time + duration;
            if (new_lb<0)
            {
              time_interval= Interval(0, new_ub); //un temps négatif n'a aucun sens
            }
            else
            {
              time_interval= Interval(new_lb, new_ub);
            }

            // Accumulate time for the next segment
            cumulative_time = new_ub;
        }
    }
    Real_time_branching = remove_null_intervals(Real_time_branching);
    return Real_time_branching;
}


void recordFinalBranching(const std::vector<std::vector<std::pair<IntervalVector, Interval>>>& Final_branching) {
    std::cout << "\n=== Final Branching Output ===\n";
          std::ofstream branch_result;
    branch_result.open("branch_result.txt");
    for (size_t i = 0; i < Final_branching.size(); i++) { // Fixed: Use .size() instead of .first.size()
        std::cout << "Branch " << i + 1 << " (Positions to reach node):\n";

        if (Final_branching[i].empty()) { // Fixed: Use Final_branching[i].empty()
            std::cout << "  [Empty Path]\n";
        }

        for (size_t j = 0; j < Final_branching[i].size(); j++) {
            // Fixed: Use Final_branching[i][j].first (IntervalVector) and Final_branching[i][j].second (Interval)
            std::cout << "  Step " << j + 1 << ": " << Final_branching[i][j].first 
                      << " , time: " << Final_branching[i][j].second << std::endl;
                    if (Final_branching[i][j].first[0].lb()>1e-4 && Final_branching[i][j].first[1].lb()>1e-4 && j%50==0)
                    {
                      branch_result << Final_branching[i][j].first[0] <<" ; "<<Final_branching[i][j].first[1] <<std::endl; //branching result là
                    }
                                        
        }

        std::cout << "--------------------------------\n";
    }
    branch_result.close();
}

void Recording_simulation(const std::vector<std::vector<node>>& final_tree){
         std::vector<std::vector<std::pair<IntervalVector, Interval>>> Final_branching;

const int size_tree = final_tree.size() - 1; // Last index
std::cout << "Size of tree: " << size_tree << std::endl;

// Resize Final_branching to match the number of nodes in the last layer, necessary for insert
Final_branching.resize(final_tree[size_tree].size());

for (size_t i = 0; i < final_tree[size_tree].size(); i++) { 
    std::cout << "Index parent node branch " << i + 1 << " : ";

    for (size_t j = 0; j < final_tree[size_tree][i].path_index.size(); j++) {
        int parent_index = final_tree[size_tree][i].path_index[j];  // Get parent index to get Jn boxes

        std::cout << parent_index << " > ";

        // Ensure the parent node index is valid
        if (parent_index < final_tree[j].size()) {
            // Append Jn_vector contents to Final_branching[i]
            Final_branching[i].insert(Final_branching[i].end(),
                                      final_tree[j][parent_index].Jn_vector.begin(),
                                      final_tree[j][parent_index].Jn_vector.end()); //maintenant faut récuperer tout les temps, fait
        } else {
            std::cerr << "Warning: Invalid parent index " << parent_index << " for node " << j << std::endl; //ça devrait pas arriver mais au cas où
        }
    }
    std::cout << std::endl;
}

std::vector<std::vector<std::pair<IntervalVector, Interval>>> Real_time_branching = reconstruct_real_time(Final_branching);
recordFinalBranching(Real_time_branching);
}

int main(){

std::vector<std::vector<node>> final_tree;

    const int n= 6; ///nombre d'état dans le système différentiel
    Variable y(n);
    IntervalVector yinit(n);
    yinit[0] = Interval(0,0.01);  //x
    yinit[1] = Interval(0,0.01);   //y
    yinit[2] = Interval(0);  //u'
    yinit[3] = Interval(0);  //theta'
    yinit[4] = Interval(0.5);  //v_ref
    yinit[5] = Interval(0);  //theta_ref

  AF_fAFFullI::setAffineNoiseNumber(250);
  Affine2Vector yinit_aff(yinit, true);

    std::vector<node> init_row;
    init_row.push_back(node(0, yinit_aff,{},NN_inputs_from_state(yinit_aff, {0,1,5})));
    final_tree.push_back(init_row);
std::cout<<"---------------simulation initiale---------------"<<std::endl;

    for (size_t i = 1; i < 25; i++)
    {
        std::cout<<"---------------Sequence : "<< i <<"---------------"<<std::endl;
        std::vector<node> temp_row;

        for (size_t j = 0; j < final_tree[i-1].size(); j++)
        {   
            for (size_t k = 0; k < final_tree[i-1][j].paved_boxes.size(); k++)
            {
                std::cout<<"---------------Noeud : "<< temp_row.size() <<"---------------"<<std::endl;
                temp_row.push_back(node(temp_row.size(), 
                final_tree[i-1][j].final_box[0], 
                final_tree[i-1][j].path_index, 
                final_tree[i-1][j].paved_boxes[k]
                ));
            }
        }

        final_tree.push_back(temp_row);
    }

Recording_simulation(final_tree);

return 1;
}
